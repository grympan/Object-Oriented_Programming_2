#include <iostream>
#include <string>

#include "Human.h"

using namespace std;

int main()
{
	CHuman objTK(180, 70);

	cout << "First Taekang's information" << endl;;
	objTK.printMemberVar();

	return 0;
}
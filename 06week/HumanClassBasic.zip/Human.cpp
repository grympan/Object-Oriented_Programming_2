#include <iostream>
using namespace std;

#include "Human.h"

CHuman::CHuman(int nH, int nW)
	: nHeight(nH), nWeight(nW)
{
}

CHuman::~CHuman(){
	cout << "End of CHuman class" << endl;
}

void CHuman::eat(){
	nWeight += 10;
}
void CHuman::sleep(){
	nHeight++;
}
void CHuman::setHeight(int nH){
	nHeight = (nH < 0) ? 0 : nH; //validation
}
void CHuman::setWeight(int nW){
	nWeight = (nW < 0) ? 0 : nW; //validation
}
int CHuman::getHeight(){
	return nHeight;
}
int CHuman::getWeight(){
	return nWeight;
}

void CHuman::printMemberVar(){
	cout << "Height : " << nHeight << endl;
	cout << "Weight : " << nWeight << endl;
}
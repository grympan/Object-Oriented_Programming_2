#ifndef HUMAN_H
#define HUMAN_H

#include <string>

using namespace std;

class CHuman{
private:
	// member var
	int nWeight;
	int nHeight;

public:
	// constructor
	CHuman(int nH = 0, int nW = 0);

	// destructor
	~CHuman();
	
	// member function
	void eat();
	void sleep();
	void setHeight(int nH);
	void setWeight(int nW);
	int getHeight();
	int getWeight();

	void printMemberVar();

};

#endif






